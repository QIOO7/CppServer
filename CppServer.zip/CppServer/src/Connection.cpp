#include <iostream>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <cassert>
#include "Connection.h"
#include "util.h"

#define ReadNonBlocking_BUFFER 1024

Connection::Connection(EventLoop* loop, Socket* sock) : m_loop(loop), m_sock(sock)
{
    if (m_loop != nullptr)
    {
        m_channel = new Channel(m_loop, m_sock->GetFd());   // 该连接的Channel
        m_channel->EnableRead();    // 打开读事件监听
        m_channel->UseET(); // 使用ET模式，可以让epoll更加高效，支持更多并发
    }
    m_read_buffer = new Buffer();
    m_send_buffer = new Buffer();
    m_state = State::Connected;
}

Connection::~Connection()
{
    if (m_loop != nullptr)
        delete m_channel;
    delete m_sock;
    delete m_read_buffer;
    delete m_send_buffer;
}

void Connection::Read()
{
    ASSERT(m_state == State::Connected, "connection state is disconnected!");
    m_read_buffer->Clear();
    if (m_sock->IsNonBlocking())
        ReadNonBlocking();
    else 
        ReadBlocking();
}

void Connection::Write()
{
    ASSERT(m_state == State::Connected, "connection state is disconnected!");
    if (m_sock->IsNonBlocking())
        WriteNonBlocking();
    else
        WriteBlocking();
    m_send_buffer->Clear();
}

void Connection::Close()
{
    m_delete_connectioin_callback(m_sock);
}

Connection::State Connection::GetState()
{
    return m_state;
}

Socket* Connection::GetSocket()
{
    return m_sock;
}

Buffer* Connection::GetReadBuffer()
{
    return m_read_buffer;
}

Buffer* Connection::GetSendBuffer()
{
    return m_send_buffer;
}

const char* Connection::ReadBuffer()
{
    return m_read_buffer->ToStr();
}

const char* Connection::SendBuffer()
{
    return m_send_buffer->ToStr();
}

void Connection::GetlineSendBuffer()
{
    m_send_buffer->GetLine();
}

void Connection::SetSendBuffer(const char* str)
{
    m_send_buffer->SetBuf(str);
}

void Connection::SetOnConnectCallback(std::function<void(Connection*)> const &callback)
{
    m_on_connect_callback = callback;
    m_channel->SetReadCallback([this](){ m_on_connect_callback(this); });
}

void Connection::SetDeleteConnectionCallback(std::function<void(Socket*)> const &callback)
{
    m_delete_connectioin_callback = callback;
}

void Connection::ReadNonBlocking()
{
    int sockfd = m_sock->GetFd();
    char buf[ReadNonBlocking_BUFFER];
    while (true)    // 使用非阻塞IO读取客户端buffer，一次读取buf大小数据，直到全部读取完毕
    {
        memset(&buf, 0, sizeof(buf));
        ssize_t read_bytes = read(sockfd, buf, sizeof(buf));

        if (read_bytes > 0)
            m_read_buffer->Append(buf, read_bytes);
        // read()返回-1，表示发生错误
        else if (read_bytes == -1 && errno == EINTR)    // 客户端正常中断，继续读取
        {
            std::cout << "continue reading" << std::endl;
            continue;
        }
        else if (read_bytes == -1 && ((errno == EAGAIN) || (errno == EWOULDBLOCK))) // 非阻塞IO，表示没有数据可读
            break;
        else if (read_bytes == 0)   // read()返回0，表示EOF，客户端断开连接
        {
            printf("read EOF, client fd %d disconnected\n", sockfd);
            m_state = State::Closed;
            break;
        }
        else
        {
            printf("Other error on client fd %d\n", sockfd);
            m_state = State::Closed;
            break;
        }
    }
}

void Connection::WriteNonBlocking()
{
    int sockfd = m_sock->GetFd();
    char buf[m_send_buffer->Size()];
    memcpy(buf, m_send_buffer->ToStr(), m_send_buffer->Size());
    int data_size = m_send_buffer->Size();
    int data_left = data_size;
    while (data_left > 0)
    {
        ssize_t write_bytes = write(sockfd, buf + data_size - data_left, data_left);
        if (write_bytes == -1)
        {
            if (errno == EINTR)
            {
                std::cout << "continue writing" << std::endl;
                continue;
            } 
            else if (errno == EAGAIN)
                break;
            else
            {
                printf("Other error on client fd %d\n", sockfd);
                m_state = State::Closed;
                break;
            }
        }
        data_left -= write_bytes;
    }
}

void Connection::ReadBlocking()
{
    int sockfd = m_sock->GetFd();
    unsigned int rcv_size = 0;
    socklen_t len = sizeof(rcv_size);
    getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &rcv_size, &len);
    char buf[rcv_size];
    ssize_t read_bytes = read(sockfd, buf, sizeof(buf));
    if (read_bytes > 0)
        m_read_buffer->Append(buf, read_bytes);
    else if (read_bytes == 0)
    {
        printf("read EOF, blocking client fd %d disconnected\n", sockfd);
        m_state = State::Closed;
    }
    else if (read_bytes == -1)
    {
        printf("Other error on client fd %d\n", sockfd);
        m_state = State::Closed;
    }
}

void Connection::WriteBlocking()
{
    // 没有处理m_send_buffer数据大于TCP写缓冲区的情况，可能会有bug
    int sockfd = m_sock->GetFd();
    ssize_t write_bytes = write(sockfd, m_send_buffer->ToStr(), m_send_buffer->Size());
    if (write_bytes == -1)
    {
        printf("Other error on client fd %d\n", sockfd);
        m_state = State::Closed;
    }
}
