#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__ 

#include <functional>
#include "Socket.h"
#include "Channel.h"
#include "Macros.h"

class EventLoop;
class Socket;
class Channel;

class Acceptor {
public:
    explicit Acceptor(EventLoop *loop);
    ~Acceptor();

    DISALLOW_COPY_AND_MOVE(Acceptor);

    void AcceptConnection();
    void SetNewConnectionCallback(std::function<void(Socket*)> const &callback);

private:
    EventLoop* m_loop;
    Socket* m_sock;
    Channel* m_channel;
    std::function<void(Socket*)> m_new_connection_callback;
};

#endif
