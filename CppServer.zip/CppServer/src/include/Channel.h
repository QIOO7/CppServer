#ifndef __CHANNEL_H__
#define __CHANNEL_H__

#include <functional>
#include "EventLoop.h"
#include "Macros.h"

class Socket;
class EventLoop;

class Channel {
public:
    Channel(EventLoop* loop, int fd);
    ~Channel();

    DISALLOW_COPY_AND_MOVE(Channel);

    void UseET();   // ʹ��ETģʽ��������epoll���Ӹ�Ч��֧�ָ��ಢ��
    void HandleEvent();
    void EnableRead();

    uint32_t GetReadyEvents();
    void SetReadyEvents(uint32_t ev);

    bool GetInEpoll();
    void SetInEpoll(bool in = true);

    int GetFd();
    uint32_t GetListenEvents();
    void SetReadCallback(std::function<void()> const &callback);

private:
    EventLoop* m_loop;
    int m_fd;
    uint32_t m_listen_events;
    uint32_t m_ready_events;
    bool m_in_epoll;
    std::function<void()> m_read_callback;
    std::function<void()> m_write_callback;
};

#endif
