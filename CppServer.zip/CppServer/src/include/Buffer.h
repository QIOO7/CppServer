#ifndef __BUFFER_H__
#define __BUFFER_H__

#include <string>
#include "Macros.h"

class Buffer {
public:
    Buffer() = default;
    ~Buffer() = default;

    DISALLOW_COPY_AND_MOVE(Buffer);

    void Append(const char* str, int size);
    ssize_t Size();
    const char *ToStr();
    void Clear();
    void GetLine();
    void SetBuf(const char* buf);

private:
    std::string m_buf;
};

#endif
