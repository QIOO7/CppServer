#ifndef __EVENTLOOP_H__
#define __EVENTLOOP_H__

#include <functional>
#include "Epoll.h"
#include "Channel.h"
#include "Macros.h"

class Epoll;
class Channel;

class EventLoop {
public:
    EventLoop();
    ~EventLoop();

    DISALLOW_COPY_AND_MOVE(EventLoop);

    void Loop();    // �����¼�����
    void UpdateChannel(Channel* ch);

private:
    Epoll* m_epoll{nullptr};
    bool m_quit{false};
};

#endif
