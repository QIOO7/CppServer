#ifndef __UTIL_H__
#define __UTIL_H__

#include <string>

void ErrorIf(bool condition, std::string errmsg);

#endif
