#ifndef __CONNECTION_H__
#define __CONNECTION_H__

#include <functional>
#include "Socket.h"
#include "Channel.h"
#include "Buffer.h"
#include "Macros.h"

class EventLoop;
class Socket;
class Channel;
class Buffer;

class Connection {
public:
    enum State {
        Invalid = 1,
        Handshaking,
        Connected,
        Closed,
        Failed,
    };

    Connection(EventLoop* loop, Socket* sock);
    ~Connection();
    
    DISALLOW_COPY_AND_MOVE(Connection);

    void Read();
    void Write();
    void Close();
    State GetState();

    Socket* GetSocket();
    Buffer* GetReadBuffer();
    Buffer* GetSendBuffer();
    const char* ReadBuffer();
    const char* SendBuffer();

    void GetlineSendBuffer();
    void SetSendBuffer(const char* str);

    void SetOnConnectCallback(std::function<void(Connection*)> const &callback);
    void SetDeleteConnectionCallback(std::function<void(Socket*)> const &callback);

private:
    EventLoop* m_loop;
    Socket* m_sock;
    Channel* m_channel{nullptr};
    State m_state{State::Invalid};
    Buffer* m_read_buffer{nullptr};
    Buffer* m_send_buffer{nullptr};
    std::function<void(Connection*)> m_on_connect_callback;
    std::function<void(Socket*)> m_delete_connectioin_callback;

    void ReadNonBlocking();
    void WriteNonBlocking();
    void ReadBlocking();
    void WriteBlocking();
};

#endif
