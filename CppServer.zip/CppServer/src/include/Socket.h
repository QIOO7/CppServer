#ifndef __SOCKET_H__
#define __SOCKET_H__

#include <arpa/inet.h>
#include "Macros.h"

class InetAddress {
public:
    InetAddress() = default;
    InetAddress(const char* ip, uint16_t port);
    ~InetAddress() = default;

    DISALLOW_COPY_AND_MOVE(InetAddress);

    const char* GetIp();
    uint16_t GetPort();
    sockaddr_in GetAddr();
    void SetAddr(sockaddr_in addr);

private:
    struct sockaddr_in m_addr {};
};

class Socket {
public:
    Socket();
    explicit Socket(int fd);
    ~Socket();

    DISALLOW_COPY_AND_MOVE(Socket);

    void Bind(InetAddress* addr);
    void Listen();
    int Accept(InetAddress* addr);
    void Connect(InetAddress* addr);
    void Connect(const char* ip, uint16_t port);

    int GetFd();
    void SetNonBlocking();
    bool IsNonBlocking();

private:
    int m_fd{-1};
};

#endif
