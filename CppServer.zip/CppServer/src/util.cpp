#include <cstdio>
#include <cstdlib>
#include "util.h"

void ErrorIf(bool condition, std::string errmsg)
{
    if(condition)
    {
        perror(errmsg.c_str());
        exit(EXIT_FAILURE);
    }
}
