#include <iostream>
#include "Acceptor.h"

Acceptor::Acceptor(EventLoop *loop) : m_loop(loop), m_sock(nullptr), m_channel(nullptr)
{
    m_sock = new Socket();
    InetAddress* addr = new InetAddress("127.0.0.1", 8888);
    m_sock->Bind(addr);
    m_sock->Listen();

    m_channel = new Channel(m_loop, m_sock->GetFd());
    std::function<void()> cb = std::bind(&Acceptor::AcceptConnection, this);
    m_channel->SetReadCallback(cb);
    m_channel->EnableRead();
    delete addr;
}

Acceptor::~Acceptor()
{
    delete m_channel;
    delete m_sock;
}

void Acceptor::AcceptConnection()
{
    InetAddress* clnt_addr = new InetAddress();
    Socket* clnt_sock = new Socket(m_sock->Accept(clnt_addr));
    
    std::cout << "new client fd " << clnt_sock->GetFd() << "! IP: " <<
        clnt_addr->GetIp() << " Port: " << clnt_addr->GetPort() << std::endl;

    clnt_sock->SetNonBlocking();    // ET��Ҫ���������ʽsocketʹ��
    m_new_connection_callback(clnt_sock);
    delete clnt_addr;
}

void Acceptor::SetNewConnectionCallback(std::function<void(Socket*)> const &callback)
{
    m_new_connection_callback = callback;
}
