#include <unistd.h>
#include <cstring>
#include "Epoll.h"
#include "util.h"

#define MAX_EVENTS 1024

Epoll::Epoll()
{
    m_epfd = epoll_create1(0);
    ErrorIf(m_epfd == -1, "epoll create error");
    m_events = new epoll_event[MAX_EVENTS];
    bzero(m_events, sizeof(*m_events) * MAX_EVENTS);
}

Epoll::~Epoll()
{
    if(m_epfd != -1)
    {
        close(m_epfd);
        m_epfd = -1;
    }
    delete [] m_events;
}

std::vector<Channel*> Epoll::Poll(int timeout)
{
    std::vector<Channel *> active_channels;
    int nfds = epoll_wait(m_epfd, m_events, MAX_EVENTS, timeout);
    ErrorIf(nfds == -1, "epoll wait error");
    for (int i = 0; i < nfds; ++i)
    {
        Channel* ch = (Channel*)m_events[i].data.ptr;
        ch->SetReadyEvents(m_events[i].events);
        active_channels.push_back(ch);
    }

    return active_channels;
}

void Epoll::UpdateChannel(Channel* ch)
{
    int fd = ch->GetFd();
    struct epoll_event ev {};
    ev.data.ptr = ch;
    ev.events = ch->GetListenEvents();
    if (!ch->GetInEpoll())
    {
        ErrorIf(epoll_ctl(m_epfd, EPOLL_CTL_ADD, fd, &ev) == -1, "epoll add error");
        ch->SetInEpoll();
    }
    else    // epoll���Ѵ���channel�е�fd�������޸�
    {
        ErrorIf(epoll_ctl(m_epfd, EPOLL_CTL_MOD, fd, &ev) == -1, "epoll modify error");
    }
}

void Epoll::DeleteChannel(Channel* ch)
{
    int fd = ch->GetFd();
    ErrorIf(epoll_ctl(m_epfd, EPOLL_CTL_DEL, fd, nullptr) == -1, "epoll delete error");
    ch->SetInEpoll(false);
}
