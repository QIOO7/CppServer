#include <unistd.h>
#include <sys/epoll.h>
#include "Channel.h"
#include "Socket.h"

Channel::Channel(EventLoop* loop, int fd)
    : m_loop(loop), m_fd(fd), m_listen_events(0), m_ready_events(0), m_in_epoll(false) {}

Channel::~Channel()
{
    if (m_fd != -1)
    {
        close(m_fd);
        m_fd = -1;
    }
}

void Channel::UseET()
{
    m_listen_events |= EPOLLET;
    m_loop->UpdateChannel(this);
}

void Channel::HandleEvent()
{
    if (m_ready_events & (EPOLLIN | EPOLLPRI))
        m_read_callback();
    if (m_ready_events & (EPOLLOUT))
        m_write_callback();
}

void Channel::EnableRead()
{
    m_listen_events |= EPOLLIN | EPOLLPRI;
    m_loop->UpdateChannel(this);
}

uint32_t Channel::GetReadyEvents()
{
    return m_ready_events;
}

void Channel::SetReadyEvents(uint32_t ev)
{
    m_ready_events = ev;
}

bool Channel::GetInEpoll()
{
    return m_in_epoll;
}

void Channel::SetInEpoll(bool in)
{
    m_in_epoll = in;
}

int Channel::GetFd()
{
    return m_fd;
}

uint32_t Channel::GetListenEvents()
{
    return m_listen_events;
}

void Channel::SetReadCallback(std::function<void()> const &callback)
{
    m_read_callback = callback;
}
