#include <vector>
#include "EventLoop.h"

EventLoop::EventLoop()
{ 
    m_epoll = new Epoll();
}

EventLoop::~EventLoop()
{
    delete m_epoll;
}


void EventLoop::Loop()
{
    while(!m_quit)
    {
        std::vector<Channel*> chs;
        chs = m_epoll->Poll();
        for (auto &ch: chs)
            ch->HandleEvent();
    }
}

void EventLoop::UpdateChannel(Channel* ch)
{
    m_epoll->UpdateChannel(ch);
}
