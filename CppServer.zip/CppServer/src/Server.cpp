#include <unistd.h>
#include <functional>
#include "Server.h"
#include "util.h"

Server::Server(EventLoop *loop) : m_main_reactor(loop), m_acceptor(nullptr), m_thread_pool(nullptr) {    
    m_acceptor = new Acceptor(m_main_reactor);  // Acceptor由且只由mainReactor负责
    std::function<void(Socket*)> cb = std::bind(&Server::NewConnection, this, std::placeholders::_1);
    m_acceptor->SetNewConnectionCallback(cb);

    int size = static_cast<int>(std::thread::hardware_concurrency());  // 线程数量，也是subReactor数量
    m_thread_pool = new ThreadPool(size);
    for (int i = 0; i < size; ++i)
        m_sub_reactors.push_back(new EventLoop());  // 每一个线程是一个EventLoop
    for (int i = 0; i < size; ++i)
    {
        std::function<void()> sub_loop = std::bind(&EventLoop::Loop, m_sub_reactors[i]);
        m_thread_pool->Add(std::move(sub_loop));  // 开启所有线程的事件循环
    }
}

Server::~Server()
{
    delete m_acceptor;
    delete m_thread_pool;
}

void Server::NewConnection(Socket* sock)
{
    ErrorIf(sock->GetFd() == -1, "new connection error");
    uint64_t random = sock->GetFd() % m_sub_reactors.size();         // 调度策略：全随机
    Connection *conn = new Connection(m_sub_reactors[random], sock);  // 分配给一个subReactor
    std::function<void(Socket*)> cb = std::bind(&Server::DeleteConnection, this, std::placeholders::_1);
    conn->SetDeleteConnectionCallback(cb);
    conn->SetOnConnectCallback(m_on_connect_callback);
    m_connections[sock->GetFd()] = conn;
}

void Server::OnConnect(std::function<void(Connection*)> fn)
{
    m_on_connect_callback = std::move(fn);
}

void Server::DeleteConnection(Socket* sock)
{
    int sockfd = sock->GetFd();
    auto it = m_connections.find(sockfd);
    if (it != m_connections.end())
    {
        Connection* conn = m_connections[sockfd];
        m_connections.erase(sockfd);
        delete conn;
        conn = nullptr;
    }
}
