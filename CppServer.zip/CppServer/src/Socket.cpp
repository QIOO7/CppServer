#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <cstring>
#include <cstdio>
#include <cerrno>
#include "Socket.h"
#include "util.h"

InetAddress::InetAddress(const char* ip, uint16_t port)
{
    memset(&m_addr, 0, sizeof(m_addr));
    m_addr.sin_family = AF_INET;
    m_addr.sin_addr.s_addr = inet_addr(ip);
    m_addr.sin_port = htons(port);
}

const char *InetAddress::GetIp()
{
    return inet_ntoa(m_addr.sin_addr);
}

uint16_t InetAddress::GetPort()
{
    return ntohs(m_addr.sin_port);
}

sockaddr_in InetAddress::GetAddr()
{
    return m_addr;
}

void InetAddress::SetAddr(sockaddr_in addr)
{
    m_addr = addr;
}

Socket::Socket()
{
    m_fd = socket(AF_INET, SOCK_STREAM, 0);
    ErrorIf(m_fd == -1, "socket create error");
}

Socket::Socket(int fd) : m_fd(fd)
{
    ErrorIf(m_fd == -1, "socket create error");
}

Socket::~Socket()
{
    if(m_fd != -1)
    {
        close(m_fd);
        m_fd = -1;
    }
}

void Socket::Bind(InetAddress* addr)
{
    struct sockaddr_in tmp_addr = addr->GetAddr();
    ErrorIf(::bind(m_fd, (sockaddr *)&tmp_addr, sizeof(tmp_addr)) == -1, "socket bind error");
}

void Socket::Listen()
{
    ErrorIf(::listen(m_fd, SOMAXCONN) == -1, "socket listen error");
}

int Socket::Accept(InetAddress* addr)
{
    // for server socket
    int clnt_sockfd = -1;
    struct sockaddr_in tmp_addr {};
    socklen_t addr_len = sizeof(tmp_addr);
    if (IsNonBlocking())
    {
        while (true)
        {
            clnt_sockfd = ::accept(m_fd, (sockaddr *)&tmp_addr, &addr_len);
            if (clnt_sockfd == -1 && ((errno == EAGAIN) || (errno == EWOULDBLOCK)))
            {
                //std::count << "no connection yet" << std::endl;
                continue;
            }
            else if (clnt_sockfd == -1)
                ErrorIf(true, "socket accept error");
            else
                break;
        }
    }
    else
    {
        clnt_sockfd = ::accept(m_fd, (sockaddr *)&tmp_addr, &addr_len);
        ErrorIf(clnt_sockfd == -1, "socket accept error");
    }
    addr->SetAddr(tmp_addr);
    return clnt_sockfd;
}

void Socket::Connect(InetAddress* addr)
{
    // for client socket
    struct sockaddr_in tmp_addr = addr->GetAddr();
    if (IsNonBlocking())
    {
        while (true)
        {
            int ret = ::connect(m_fd, (sockaddr *)&tmp_addr, sizeof(tmp_addr));
            if (ret == 0)
                break;
            if (ret == -1)
            {
                if (errno == EINPROGRESS)
                {
                    continue;
                    /* ���ӷ�����ʽsockfd�����������
                        The socket is nonblocking and the connection cannot be
                      completed immediately.  (UNIX domain sockets failed with
                      EAGAIN instead.)  It is possible to select(2) or poll(2)
                      for completion by selecting the socket for writing.  After
                      select(2) indicates writability, use getsockopt(2) to read
                      the SO_ERROR option at level SOL_SOCKET to determine
                      whether connect() completed successfully (SO_ERROR is
                      zero) or unsuccessfully (SO_ERROR is one of the usual
                      error codes listed here, explaining the reason for the
                      failure).
                      ����Ϊ�˼򵥡���������ֱ��������ɣ��൱������ʽ
                    */
                }
                else
                    ErrorIf(true, "socket connect error");
            }
        }
    }
    else
        ErrorIf(::connect(m_fd, (sockaddr *)&tmp_addr, sizeof(tmp_addr)) == -1, "socket connect error");
}

void Socket::Connect(const char* ip, uint16_t port)
{
    InetAddress* addr = new InetAddress(ip, port);
    Connect(addr);
    delete addr;
}

int Socket::GetFd()
{
    return m_fd;
}

void Socket::SetNonBlocking()
{
    fcntl(m_fd, F_SETFL, fcntl(m_fd, F_GETFL) | O_NONBLOCK);
}

bool Socket::IsNonBlocking()
{
    return (fcntl(m_fd, F_GETFL) & O_NONBLOCK) != 0;
}
